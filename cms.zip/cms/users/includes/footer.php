 <footer class="site-footer">
          <div class="text-center">
              2019 - PHPGurukul.com
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>